# Current completion checklist

The original feature wishlist is preserved in
`history/pre-closeout-20261021/RESEARCH_FEATURE_MEGA_CHECKLIST.md`.
It describes future research, not a requirement to invent unsupported models.

- [x] Canonical research state, history and fixed budget.
- [x] Precise hypothesis, prior-art boundary, falsifier and full model contract.
- [x] Thirty concrete flaws with repairs, limits and evidence requirements.
- [x] Frozen development protocol distinct from inspected predecessor outcomes.
- [x] Fully implemented model, training, inference, checkpoints and safeguards.
- [x] Group-isolated repetitions, matched-tree controls and stronger baselines.
- [x] Ablations, noise/scale/permutation probes and five chemical holdouts.
- [x] Hosted tests and complete synthetic end-to-end dry run.
- [x] Real Kaggle execution with full raw predictions and retained evidence.
- [x] Independent numerical recomputation and source/manifest verification.
- [x] Complete manuscript source, artifact-generated tables and figures.
- [ ] Independently operated scientific reproduction (not supplied by self-verification).
- [ ] Protected external/prospective validation (not restored by new CV splits).
- [ ] Final author metadata and venue-specific submission approval.

Final PDF/build/GitHub receipts are recorded in `RESEARCH_STATE.json` and `artifacts/`.
