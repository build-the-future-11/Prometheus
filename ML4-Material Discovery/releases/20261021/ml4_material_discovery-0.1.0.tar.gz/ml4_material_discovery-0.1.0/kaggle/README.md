# Kaggle execution

The Kaggle artifact consists of a private source dataset and a private script
notebook. `kernel/run_hosted.py` copies the read-only dataset to Kaggle working
storage and invokes `scripts/run_kaggle.sh` with the immutable run ID
`kaggle-development-v1-r1`.

Kaggle transparently expands recognized compressed dataset files. The original
SHA-256-bound `.json.gz` input is therefore also transported inside the opaque
`frozen-data.bundle`; the launcher restores that exact byte sequence before the
data contract and integration tests execute.

The runner executes the test suite, validates the pinned data, records
preflight admission, runs the unchanged `development-v1` protocol, verifies
the run manifest, enforces the numerical-paper release gate, and emits a
SHA-256-bound archive. A failed resource guard or scientific run remains a
failed Kaggle version; it is never converted into a successful result.
