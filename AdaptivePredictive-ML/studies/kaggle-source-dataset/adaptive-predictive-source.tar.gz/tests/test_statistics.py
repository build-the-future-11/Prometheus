from __future__ import annotations

import pytest

from adaptive_predictive.statistics import paired_block_bootstrap


def test_paired_bootstrap_detects_consistent_improvement() -> None:
    result = paired_block_bootstrap(
        {"a": [-0.2] * 40, "b": [-0.1] * 40},
        block_length=7,
        repetitions=500,
        seed=17,
    )
    assert result.estimate == pytest.approx(-0.15)
    assert result.ci_upper < 0
    assert result.probability_improvement == 1.0


def test_paired_bootstrap_rejects_short_series() -> None:
    with pytest.raises(ValueError, match="complete block"):
        paired_block_bootstrap({"a": [1.0, 2.0]}, block_length=7, repetitions=10, seed=1)

