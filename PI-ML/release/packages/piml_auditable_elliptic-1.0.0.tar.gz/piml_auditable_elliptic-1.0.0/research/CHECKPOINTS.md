# Research checkpoint ledger

| Checkpoint | Status and evidence |
|---|---|
| 1 Idea ready | Narrow, falsifiable controlled replication/audit; prior-art boundary in LITERATURE.md. No novel solver-family claim. |
| 2 Model specification | S2_SPECIFICATION.md and paper/methods.tex specify all components, dimensions, fitting, inference and safeguards. |
| 3 Methodology | Full nine-method, two-grid, two-tolerance, three-regime matrix; single joint primary gate. |
| 4 Model implemented | src/piml/s2.py; 26 hosted numerical/contract tests passed. |
| 5 Experiment system | Full development and confirmation executed, retained and semantically verified. |
| 6 Run ready | Tests preceded both Kaggle scientific stages; local resource refusal preserved. |
| 7 Frozen | Source commit 66d5721; freeze commit e864d62, published and read back before outcome interpretation. Source/config bytes match downloaded confirmation. |
| 8 Evidence locked | S1 NEGATIVE; S2 SUPPORTED within primary scope; 17,280 rows, zero convergence failures. Hashes and full numerical replay passed. |
| 9 Verification | Original semantic verification passed; clean wheel environment and separately implemented SciPy/flux/exact-bootstrap audit in progress. Not independent investigator reproduction. |
| 10 Release | Final PDF rendering, package validation, archive hashes and GitHub final artifact readback in progress. |
